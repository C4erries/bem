"use strict";
$.Msg("ui manifest loaded");
